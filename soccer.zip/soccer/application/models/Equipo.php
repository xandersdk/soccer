<?php
class Equipo extends CI_Model {
    function __construct() {
        parent::__construct();
    }

    function insertar($datos) {
        $respuesta = $this->db->insert("equipo", $datos);
        return $respuesta;
    }

    function consultarTodos() {
        $equipos = $this->db->get("equipo");
        if ($equipos->num_rows() > 0) {
            return $equipos->result();
        } else {
            return false;
        }
    }

    function tiene_jugador($id_equi) {
        $this->db->where('fk_id_equi', $id_equi);
        $query = $this->db->get('jugador');
        return $query->num_rows() > 0;
    }

    function eliminar($id) {
        if (!$this->tiene_jugador($id)) {
            $this->db->where("id_equi", $id);
            return $this->db->delete("equipo");
        } else {
            return false; // Indica que no se puede eliminar porque hay registros en Estacionamiento
        }
    }

    function obtenerPorId($id) {
        $this->db->where("id_equi", $id);
        $equipos = $this->db->get("equipo");
        if ($equipos->num_rows() > 0) {
            return $equipos->row();
        } else {
            return false;
        }
    }

    function actualizar($id, $datos) {
        $this->db->where("id_equi", $id);
        return $this->db->update("equipo", $datos);
    }
}
?>
