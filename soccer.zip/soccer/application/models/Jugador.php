<?php
class Jugador extends CI_Model
{
    function __construct()
    {
        parent::__construct();
    }

    function insertar($datos)
    {
        $respuesta = $this->db->insert("jugador", $datos);
        return $respuesta;
    }

    function consultarTodos()
    {
        $jugadores = $this->db->get("jugador");
        if ($jugadores->num_rows() > 0) {
            return $jugadores->result();
        } else {
            return false;
        }
    }

    function obtenerEquipo($id) {
        $this->db->select('equipo.*');
        $this->db->from('jugador');
        $this->db->join('equipo', 'jugador.fk_id_equi = equipo.id_equi', 'left');
        $this->db->where('jugador.id_jug', $id);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->row();
        } else {
            return (object) ['nombre_equi' => 'No disponible'];
        }
    }

    function obtenerPosicion($id) {
        $this->db->select('posicion.*');
        $this->db->from('jugador');
        $this->db->join('posicion', 'jugador.fk_id_pos = posicion.id_pos', 'left');
        $this->db->where('jugador.id_jug', $id);
        $query = $this->db->get();
        if ($query->num_rows() > 0) {
            return $query->row();
        } else {
            return (object) ['nombre_pos' => 'No disponible'];
        }
    }


    function eliminar($id)
    {
        $this->db->where("id_jug", $id);
        return $this->db->delete("jugador");
    }

    function obtenerPorId($id)
    {
        $this->db->where("id_jug", $id);
        $jugador = $this->db->get("jugador");
        if ($jugador->num_rows() > 0) {
            return $jugador->row();
        } else {
            return false;
        }
    }

    function actualizar($id, $datos)
    {
        $this->db->where("id_jug", $id);
        return $this->db->update("jugador", $datos);
    }
}
?>
