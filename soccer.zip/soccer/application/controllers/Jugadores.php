<?php

class Jugadores extends CI_Controller
{
    function __construct()
    {
        parent::__construct();
        $this->load->model('Jugador');
        $this->load->model('Equipo');
        $this->load->model('Posicion');
    }

    public function index()
    {
        $ListadoJugadores = $this->Jugador->consultarTodos();

        if ($ListadoJugadores) {
            foreach ($ListadoJugadores as $jugador) {
                $jugador->equipo = $this->Jugador->obtenerEquipo($jugador->id_jug);
                $jugador->posicion = $this->Jugador->obtenerPosicion($jugador->id_jug);
            }
        }

        $data['ListadoJugadores'] = $ListadoJugadores ?: [];

        $this->load->view("header");
        $this->load->view("jugadores/index", $data);
        $this->load->view("footer");
    }

    public function nuevo()
    {
        $data['equipos'] = $this->Equipo->consultarTodos();
        $data['posiciones'] = $this->Posicion->consultarTodos();

        $this->load->view("header");
        $this->load->view("jugadores/nuevo", $data);
        $this->load->view("footer");
    }

    public function editar($id)
    {
        $data['jugadorEditar'] = $this->Jugador->obtenerPorId($id);
        $data['equipo'] = $this->Equipo->consultarTodos();
        $data['posicion'] = $this->Posicion->consultarTodos();

        $this->load->view("header");
        $this->load->view("jugadores/editar", $data);
        $this->load->view("footer");
    }

    public function guardarJugador()
    {
        $datosNuevoJugador = array(
            "fk_id_equi" => $this->input->post("fk_id_equi"),
            "fk_id_pos" => $this->input->post("fk_id_pos"),
            "apellido_jug" => $this->input->post("apellido_jug"),
            "nombre_jug" => $this->input->post("nombre_jug"),
            "estatura_jug" => $this->input->post("estatura_jug"),
            "salario_jug" => $this->input->post("salario_jug"),
            "estado_jug" => $this->input->post("estado_jug"),

        );

        $this->Jugador->insertar($datosNuevoJugador);
        $this->session->set_flashdata("confirmacion", "Jugador guardado exitosamente");
        redirect('jugadores/index');
    }

    public function borrar($id_jug)
    {
        $this->Jugador->eliminar($id_jug);
        $this->session->set_flashdata("eliminacion", "Jugador eliminado exitosamente");
        redirect('jugadores/index');
    }

    public function actualizarJugador()
    {
        $id_jug = $this->input->post("id_jug");
        $datosJugador = array(
          "fk_id_equi" => $this->input->post("fk_id_equi"),
          "fk_id_pos" => $this->input->post("fk_id_pos"),
          "apellido_jug" => $this->input->post("apellido_jug"),
          "nombre_jug" => $this->input->post("nombre_jug"),
          "estatura_jug" => $this->input->post("estatura_jug"),
          "salario_jug" => $this->input->post("salario_jug"),
          "estado_jug" => $this->input->post("estado_jug"),
        );

        $this->Jugador->actualizar($id_jug, $datosJugador);
        $this->session->set_flashdata("confirmacion", "Jugador actualizado exitosamente");
        redirect('jugadores/index');
    }
}
?>
