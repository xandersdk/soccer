<!-- Contact Start -->
<div class="container-fluid py-5 mb-5">
    <div class="container">
        <div class="text-center mx-auto pb-5 wow fadeIn" style="max-width: 600px;">
            <h5 class="text-primary">Equipo</h5>
            <h1 class="mb-3">Visualizacion de Equipos</h1>
        </div>
        <div class="row g-5 mb-5 text-center table-responsive">


            <?php if ($listadoEquipos): ?>
                <table class="table table-responsive align-middle text-center table-striped" id="tbl_clientes">
                    <thead>
                        <tr class="bg-primary" style="color: white">
                            <th class="text-center">#</th>
                            <th class="text-center">Nombre</th>
                            <th class="text-center">Siglas</th>
                            <th class="text-center">Fundacion</th>
                            <th class="text-center">Region</th>
                            <th class="text-center">Numero de titulos</th>
                            <th class="text-center">Acciones</th>

                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($listadoEquipos as $equipo): ?>
                            <tr>
                                <td><?php echo $equipo->id_equi; ?></td>
                                <td><?php echo $equipo->nombre_equi; ?></td>
                                <td><?php echo $equipo->siglas_equi; ?></td>
                                <td><?php echo $equipo->fundacion_equi; ?></td>
                                <td><?php echo $equipo->region_equi; ?></td>
                                <td><?php echo $equipo->numero_titulos_equi; ?></td>
                                <td>
                                    <a href="#" onclick="confirmarEliminacionEquipo(<?php echo $equipo->id_equi; ?>);" class="btn btn-danger btn-sm"><i class="fa fa-eraser" aria-hidden="true"></i></a>
                                    <a href="<?php echo site_url('equipos/editar/').$equipo->id_equi; ?>"><button type="button" name="button" class="btn btn-success btn-sm"><i class="fa fa-pencil" aria-hidden="true"></i></button></a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>No hay Equipos disponibles.</p>
            <?php endif; ?>
        </div>
    </div>
</div>
<!-- Contact End -->
