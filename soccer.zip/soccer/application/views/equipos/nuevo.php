<!-- Contact Start -->
<div class="container-fluid py-5 mb-5">
    <div class="container">
        <div class="text-center mx-auto pb-5 wow fadeIn" style="max-width: 600px;">
            <h5 class="text-primary">Equipos</h5>
            <h1 class="mb-3">Ingresar Nuevo Equipo</h1>
        </div>
        <form class="row g-5 mb-5" action="<?php echo site_url('equipos/guardarEquipo');?>" method="post" id="frm_nuevo_equipo">
            <div class="col-md-2"></div>
            <div class="col-lg-8 wow fadeIn">
                <div class="p-5 rounded bg-primary">
                    <div class="mb-4">
                        <label for="nombre_equi" style="color: white;"><b>Nombre</b></label>
                        <input type="text" class="form-control border-0 py-3" name="nombre_equi" id="nombre_equi" placeholder="Ingrese el nombre del equipo" required>
                    </div>
                    <div class="mb-4">
                        <label for="siglas_equi" style="color: white;"><b>Siglas</b></label>
                        <input type="text" class="form-control border-0 py-3" name="siglas_equi" id="siglas_equi" placeholder="Ingrese las siglas del equipo" required>
                    </div>
                    <div class="mb-4">
                        <label for="fundacion_equi" style="color: white;"><b>Fundación</b></label>
                        <input type="text" class="form-control border-0 py-3" name="fundacion_equi" id="fundacion_equi" placeholder="Ingrese el año de fundación del equipo" required>
                    </div>
                    <div class="mb-4">
                        <label for="region_equi" style="color: white;"><b>Región</b></label>
                        <select class="form-control border-0 py-4 selectpicker" data-style="btn-primary" name="region_equi" id="region_equi" required>
                            <option value="" disabled selected>Seleccione la región</option>
                            <option value="Costa">Costa</option>
                            <option value="Sierra">Sierra</option>
                            <option value="Oriente">Oriente</option>
                            <option value="Region Insular">Región Insular</option>
                        </select>
                    </div>
                    <div class="mb-4">
                        <label for="numero_titulos_equi" style="color: white;"><b>Número de Títulos</b></label>
                        <input type="number" class="form-control border-0 py-3" name="numero_titulos_equi" id="numero_titulos_equi" placeholder="Ingrese el número de títulos del equipo" required>
                    </div>
                    <div class="text-start">
                        <button class="btn bg-success text-white py-3 px-5" type="submit">Guardar Equipo</button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<!-- Contact End -->

<!-- jQuery -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<!-- jQuery Validate -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.20.0/jquery.validate.min.js" integrity="sha512-WMEKGZ7L5LWgaPeJtw9MBM4i5w5OSBlSjTjCtSnvFJGSVD26gE5+Td12qN5pvWXhuWaWcVwF++F7aqu9cvqP0A==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.20.0/additional-methods.min.js" integrity="sha512-TiQST7x/0aMjgVTcep29gi+q5Lk5gVTUPE9XgN0g96rwtjEjLpod4mlBRKWHeBcvGBAEvJBmfDqh2hfMMmg+5A==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<!-- Bootstrap Select -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.14.0-beta3/css/bootstrap-select.min.css" integrity="sha512-r4iOSm2RyVv0xAEaVcK+ERQQqE8XAV02qTDCzP2FOHYX0JTk+xa8ccG/eYswYZ0xg0+zkWTYaVVCTfGrU/HuZg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.14.0-beta3/js/bootstrap-select.min.js" integrity="sha512-4NDuAU0qeJgxuJbU+9jEPAt+Wnlg3UeGPazc1NNHOb/JiX7QZup7VvZTxgD97omzIZ/nCioeV/OzyEKI1yoFAw==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<script type="text/javascript">
  $(document).ready(function () {
    $('.selectpicker').selectpicker();

    $.validator.addMethod("letrasSolo", function(value, element) {
      return /^[a-zA-Z\s]+$/.test(value);
    }, "Ingrese solo letras.");

    $("#frm_nuevo_equipo").validate({
      rules:{
        "nombre_equi":{
          required:true,
          letrasSolo:true
        },
        "siglas_equi":{
          required:true
        },
        "fundacion_equi":{
          required:true,
          soloNumeros:true
        },
        "region_equi":{
          required:true
        },
        "numero_titulos_equi":{
          required:true,
          soloNumeros:true
        }
      },
      messages:{
        "nombre_equi":{
          required:"Debe ingresar el nombre del equipo",
          letrasSolo:"Debe ingresar solo letras"
        },
        "siglas_equi":{
          required:"Debe ingresar las siglas del equipo"
        },
        "fundacion_equi":{
          required:"Debe ingresar el año de fundación del equipo",
          soloNumeros:"Debe ingresar solo números"
        },
        "region_equi":{
          required:"Debe ingresar la región del equipo"
        },
        "numero_titulos_equi":{
          required:"Debe ingresar el número de títulos del equipo",
          soloNumeros:"Debe ingresar solo números"
        }
      }
    });
  });
</script>

<style media="screen">
  label.error {
    color: white;
    font-weight: bold;
  }
</style>
