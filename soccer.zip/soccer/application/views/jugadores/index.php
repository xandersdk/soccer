<!-- Contact Start -->
<div class="container-fluid py-5 mb-5">
    <div class="container">
        <div class="text-center mx-auto pb-5 wow fadeIn" style="max-width: 600px;">
            <h5 class="text-primary">Jugadores</h5>
            <h1 class="mb-3">Visualización de Jugadores</h1>
        </div>
        <div class="row g-5 mb-5 text-center table-responsive">
            <?php if ($ListadoJugadores): ?>
                <table class="table table-responsive align-middle text-center table-striped" id="tbl_jugadores">
                    <thead>
                        <tr class="bg-primary" style="color: white">
                            <th class="text-center">#</th>
                            <th class="text-center">Nombre</th>
                            <th class="text-center">Apellido</th>
                            <th class="text-center">Equipo</th>
                            <th class="text-center">Posición</th>
                            <th class="text-center">Estatura</th>
                            <th class="text-center">Salario</th>
                            <th class="text-center">Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($ListadoJugadores as $jugador): ?>
                            <tr>
                                <td><?php echo $jugador->id_jug; ?></td>
                                <td><?php echo $jugador->nombre_jug; ?></td>
                                <td><?php echo $jugador->apellido_jug; ?></td>
                                <td><?php echo $jugador->equipo->nombre_equi; ?></td>
                                <td><?php echo $jugador->posicion->nombre_pos; ?></td>
                                <td><?php echo $jugador->estatura_jug; ?></td>
                                <td><?php echo $jugador->salario_jug; ?></td>
                                <td>
                                    <a href="#" onclick="confirmarEliminacionJugador(<?php echo $jugador->id_jug; ?>);" class="btn btn-danger btn-sm"><i class="fa fa-eraser" aria-hidden="true"></i></a>
                                    <a href="<?php echo site_url('jugadores/editar/').$jugador->id_jug; ?>"><button type="button" name="button" class="btn btn-success btn-sm"><i class="fa fa-pencil" aria-hidden="true"></i></button></a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>No hay jugadores disponibles.</p>
            <?php endif; ?>
        </div>
    </div>
</div>
<!-- Contact End -->
