<!-- Contact Start -->
<div class="container-fluid py-5 mb-5">
    <div class="container">
        <div class="text-center mx-auto pb-5 wow fadeIn" style="max-width: 600px;">
            <h5 class="text-primary">Editar Jugador</h5>
            <h1 class="mb-3">Actualizar Datos del Jugador</h1>
        </div>
        <form action="<?php echo site_url('jugadores/actualizarJugador');?>" method="post" id="frm_editar_jugador">
            <input type="hidden" name="id_jug" id="id_jug" value="<?php echo $jugadorEditar->id_jug; ?>">
            <div class="contact-detail position-relative p-5">
                <div class="row g-5">
                    <div class="col-md-2"></div>
                    <div class="col-lg-8 wow fadeIn">
                        <div class="p-5 rounded bg-primary">
                            <div class="mb-4">
                                <label for="fk_id_equi" style="color: white;"><b>Equipo</b></label>
                                <select name="fk_id_equi" id="fk_id_equi" class="form-control" required>
                                    <option value="" disabled>Seleccione el equipo</option>
                                    <?php foreach ($equipos as $equipo): ?>
                                        <option value="<?php echo $equipo->id_equi; ?>" <?php echo $jugadorEditar->fk_id_equi == $equipo->id_equi ? 'selected' : ''; ?>><?php echo $equipo->nombre_equi; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="mb-4">
                                <label for="fk_id_pos" style="color: white;"><b>Posición</b></label>
                                <select name="fk_id_pos" id="fk_id_pos" class="form-control" required>
                                    <option value="" disabled>Seleccione la posición</option>
                                    <?php foreach ($posiciones as $posicion): ?>
                                        <option value="<?php echo $posicion->id_pos; ?>" <?php echo $jugadorEditar->fk_id_pos == $posicion->id_pos ? 'selected' : ''; ?>><?php echo $posicion->nombre_pos; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="mb-4">
                                <label for="apellido_jug" style="color: white;"><b>Apellido</b></label>
                                <input type="text" class="form-control border-0 py-3" name="apellido_jug" id="apellido_jug" value="<?php echo $jugadorEditar->apellido_jug; ?>" required>
                            </div>
                            <div class="mb-4">
                                <label for="nombre_jug" style="color: white;"><b>Nombre</b></label>
                                <input type="text" class="form-control border-0 py-3" name="nombre_jug" id="nombre_jug" value="<?php echo $jugadorEditar->nombre_jug; ?>" required>
                            </div>
                            <div class="mb-4">
                                <label for="estatura_jug" style="color: white;"><b>Estatura (cm)</b></label>
                                <input type="number" class="form-control border-0 py-3" name="estatura_jug" id="estatura_jug" value="<?php echo $jugadorEditar->estatura_jug; ?>" required>
                            </div>
                            <div class="mb-4">
                                <label for="salario_jug" style="color: white;"><b>Salario ($)</b></label>
                                <input type="number" class="form-control border-0 py-3" name="salario_jug" id="salario_jug" value="<?php echo $jugadorEditar->salario_jug; ?>" required>
                            </div>
                            <div class="mb-4">
                                <label for="estado_jug" style="color: white;"><b>Estado</b></label>
                                <select name="estado_jug" id="estado_jug" class="form-control" required>
                                    <option value="" disabled>Seleccione el estado</option>
                                    <option value="Activo" <?php echo $jugadorEditar->estado_jug == 'Activo' ? 'selected' : ''; ?>>Activo</option>
                                    <option value="Inactivo" <?php echo $jugadorEditar->estado_jug == 'Inactivo' ? 'selected' : ''; ?>>Inactivo</option>
                                </select>
                            </div>
                            <div class="text-start">
                                <button class="btn bg-success text-white py-3 px-5" type="submit">Guardar Jugador</button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<!-- Contact End -->

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<!-- jQuery Validate -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.20.0/jquery.validate.min.js" integrity="sha512-WMEKGZ7L5LWgaPeJtw9MBM4i5w5OSBlSjTjCtSnvFJGSVD26gE5+Td12qN5pvWXhuWaWcVwF++F7aqu9cvqP0A==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.20.0/additional-methods.min.js" integrity="sha512-TiQST7x/0aMjgVTcep29gi+q5Lk5gVTUPE9XgN0g96rwtjEjLpod4mlBRKWHeBcvGBAEvJBmfDqh2hfMMmg+5A==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<script type="text/javascript">
  $(document).ready(function () {
    $.validator.addMethod("letrasSolo", function(value, element) {
      return /^[a-zA-Z\s]+$/.test(value);
    }, "Ingrese solo letras.");

    $.validator.addMethod("soloNumeros", function(value, element) {
      return /^\d+$/.test(value);
    }, "Ingrese solo números.");

    $("#frm_editar_jugador").validate({
      rules:{
        "fk_id_equi": {
          required: true
        },
        "fk_id_pos": {
          required: true
        },
        "apellido_jug": {
          required: true,
          letrasSolo: true
        },
        "nombre_jug": {
          required: true,
          letrasSolo: true
        },
        "estatura_jug": {
          required: true,
          soloNumeros: true
        },
        "salario_jug": {
          required: true,
          soloNumeros: true
        },
        "estado_jug": {
          required: true
        }
      },
      messages:{
        "fk_id_equi": {
          required: "Debe seleccionar un equipo"
        },
        "fk_id_pos": {
          required: "Debe seleccionar una posición"
        },
        "apellido_jug": {
          required: "Debe ingresar el apellido",
          letrasSolo: "Ingrese solo letras"
        },
        "nombre_jug": {
          required: "Debe ingresar el nombre",
          letrasSolo: "Ingrese solo letras"
        },
        "estatura_jug": {
          required: "Debe ingresar la estatura",
          soloNumeros: "Ingrese solo números"
        },
        "salario_jug": {
          required: "Debe ingresar el salario",
          soloNumeros: "Ingrese solo números"
        },
        "estado_jug": {
          required: "Debe seleccionar el estado"
        }
      }
    });
  });
</script>

<style media="screen">
  label.error {
    color: white;
    font-weight: bold;
  }
</style>
