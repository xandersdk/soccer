
<!--End footer-->

<!--start color switcher-->


</div><!--End wrapper-->

<!-- Bootstrap core JavaScript-->
<script src="<?php echo base_url('assets/js/popper.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/bootstrap.min.js'); ?>"></script>

<!-- simplebar js -->
<script src="<?php echo base_url('assets/plugins/simplebar/js/simplebar.js'); ?>"></script>
<!-- sidebar-menu js -->
<script src="<?php echo base_url('assets/js/sidebar-menu.js'); ?>"></script>
<!-- loader scripts -->
<script src="<?php echo base_url('assets/js/jquery.loading-indicator.js'); ?>"></script>
<!-- Custom scripts -->
<script src="<?php echo base_url('assets/js/app-script.js'); ?>"></script>
<!-- Chart js -->

<script src="<?php echo base_url('assets/plugins/Chart.js/Chart.min.js'); ?>"></script>

<!-- Index js -->
<script src="<?php echo base_url('assets/js/index.js'); ?>"></script>


</html>
