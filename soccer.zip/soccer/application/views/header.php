<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8"/>
  <meta http-equiv="X-UA-Compatible" content="IE=edge"/>
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no"/>
  <meta name="description" content=""/>
  <meta name="author" content=""/>
  <title>Campeonato de Futbol</title>

  <!-- SweetAlert2 -->
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.10.3/dist/sweetalert2.all.min.js"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11.10.3/dist/sweetalert2.min.css">

  <!-- jQuery -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

  <!-- jQuery Validate -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.20.0/jquery.validate.min.js" integrity="sha512-WMEKGZ7L5LWgaPeJtw9MBM4i5w5OSBlSjTjCtSnvFJGSVD26gE5+Td12qN5pvWXhuWaWcVwF++F7aqu9cvqP0A==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.20.0/additional-methods.min.js" integrity="sha512-TiQST7x/0aMjgVTcep29gi+q5Lk5gVTUPE9XgN0g96rwtjEjLpod4mlBRKWHeBcvGBAEvJBmfDqh2hfMMmg+5A==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

  <!-- Custom CSS -->
  <link href="<?php echo base_url('assets/css/pace.min.css'); ?>" rel="stylesheet"/>
  <script src="<?php echo base_url('assets/js/pace.min.js'); ?>"></script>
  <link rel="icon" href="<?php echo base_url('assets/images/favicon.ico'); ?>" type="image/x-icon">
  <link href="<?php echo base_url('assets/plugins/vectormap/jquery-jvectormap-2.0.2.css'); ?>" rel="stylesheet"/>
  <link href="<?php echo base_url('assets/plugins/simplebar/css/simplebar.css'); ?>" rel="stylesheet"/>
  <link href="<?php echo base_url('assets/css/bootstrap.min.css'); ?>" rel="stylesheet"/>
  <link href="<?php echo base_url('assets/css/animate.css'); ?>" rel="stylesheet" type="text/css"/>
  <link href="<?php echo base_url('assets/css/icons.css'); ?>" rel="stylesheet" type="text/css"/>
  <link href="<?php echo base_url('assets/css/sidebar-menu.css'); ?>" rel="stylesheet"/>
  <link href="<?php echo base_url('assets/css/app-style.css'); ?>" rel="stylesheet"/>
  <style>
    .sidebar-menu .menu-title {
        font-size: 18px;
        color: #fff;
    }
    .sidebar-menu .menu-item {
        font-size: 16px;
        color: #ccc;
    }
  </style>
</head>
<body class="bg-theme bg-theme1">

  <!-- Start wrapper -->
  <div id="wrapper">
      <!-- Start sidebar-wrapper -->
      <div id="sidebar-wrapper" data-simplebar="" data-simplebar-auto-hide="true">
          <div class="brand-logo">
              <a href="<?php echo site_url('clientes/index');?>">
                  <h5 class="logo-text">Campeonato</h5>
              </a>
          </div>
          <ul class="sidebar-menu do-nicescrol">
              <li class="sidebar-header menu-title">EQUIPOS</li>
              <li class="menu-item">
                  <a href="<?php echo site_url('equipos/index');?>">
                      <i class="zmdi zmdi-view-list"></i> <span>Listado Equipos</span>
                  </a>
              </li>
              <li class="menu-item">
                  <a href="<?php echo site_url('equipos/nuevo');?>">
                      <i class="zmdi zmdi-plus-square"></i> <span>Ingresar Equipo</span>
                  </a>
              </li>
              <li class="sidebar-header menu-title">POSICIONES</li>
              <li class="menu-item">
                  <a href="<?php echo site_url('posiciones/index');?>">
                      <i class="zmdi zmdi-view-list"></i> <span>Listado Posiciones</span>
                  </a>
              </li>
              <li class="menu-item">
                  <a href="<?php echo site_url('posiciones/nuevo');?>">
                      <i class="zmdi zmdi-plus-square"></i> <span>Ingresar Posición</span>
                  </a>
              </li>
              <li class="sidebar-header menu-title">JUGADORES</li>
              <li class="menu-item">
                  <a href="<?php echo site_url('jugadores/index');?>">
                      <i class="zmdi zmdi-view-list"></i> <span>Listado Jugadores</span>
                  </a>
              </li>
              <li class="menu-item">
                  <a href="<?php echo site_url('jugadores/nuevo');?>">
                      <i class="zmdi zmdi-plus-square"></i> <span>Ingresar Jugador</span>
                  </a>
              </li>
          </ul>
      </div>
  </div>

  <!-- End sidebar-wrapper -->

  <!-- Content-wrapper -->
  <div class="content-wrapper">
      <div class="container-fluid">
          <!-- Dashboard Content -->
          <!-- End Dashboard Content -->

          <!-- Overlay -->
          <!-- End overlay -->
      </div>
      <!-- End container-fluid -->
  </div>
  <!-- End content-wrapper -->

  <div class="container">
      <?php if ($this->session->flashdata('confirmacion')): ?>
      <script type="text/javascript">
        Swal.fire({
          title: "Confirmacion!",
          text: "<?php echo $this->session->flashdata('confirmacion'); ?>",
          icon: "success"
        });
      </script>
      <?php $this->session->set_flashdata('confirmacion', ''); ?>
      <?php endif; ?>
  </div>
</div>
<!-- End wrapper -->

<!-- Bootstrap core JavaScript -->
<script src="<?php echo base_url('assets/js/jquery.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/popper.min.js'); ?>"></script>
<script src="<?php echo base_url('assets/js/bootstrap.min.js'); ?>"></script>

<!-- simplebar js -->
<script src="<?php echo base_url('assets/plugins/simplebar/js/simplebar.js'); ?>"></script>
<!-- sidebar-menu js -->
<script src="<?php echo base_url('assets/js/sidebar-menu.js'); ?>"></script>
<!-- loader scripts -->
<script src="<?php echo base_url('assets/js/jquery.loading-indicator.js'); ?>"></script>
<!-- Custom scripts -->
<script src="<?php echo base_url('assets/js/app-script.js'); ?>"></script>
<!-- Chart js -->
<script src="<?php echo base_url('assets/plugins/Chart.js/Chart.min.js'); ?>"></script>
<!-- Index js -->
<script src="<?php echo base_url('assets/js/index.js'); ?>"></script>

<!-- Custom SweetAlert2 Scripts -->
<script>
  function confirmarEliminacionEstacionamiento(ID_Estacionamiento) {
      Swal.fire({
          title: '¿Estás seguro?',
          text: 'Esta acción no se puede deshacer.',
          icon: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Sí, eliminar',
          cancelButtonText: 'Cancelar'
      }).then((result) => {
          if (result.isConfirmed) {
              window.location.href = "<?php echo site_url('estacionamientos/borrar/'); ?>" + ID_Estacionamiento;
          }
      });
      return false;
  }

  function confirmarEliminacionEquipo(id_equi) {
      Swal.fire({
          title: '¿Asegurese de que no tenga relacion?',
          text: 'Caso contrario no se eliminara',
          icon: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Sí, eliminar',
          cancelButtonText: 'Cancelar'
      }).then((result) => {
          if (result.isConfirmed) {
              window.location.href = "<?php echo site_url('equipos/borrar/'); ?>" + id_equi;
          }
      });
      return false;
  }

  function confirmarEliminacionPosicion(id_pos) {
      Swal.fire({
        title: '¿Asegurese de que no tenga relacion?',
        text: 'Caso contrario no se eliminara',
          icon: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#3085d6'
            cancelButtonColor: '#d33',
            confirmButtonText: 'Sí, eliminar',
            cancelButtonText: 'Cancelar'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = "<?php echo site_url('posiciones/borrar/'); ?>" + id_pos;
            }
        });
        return false;
    }
  </script>
</body>
</html>
