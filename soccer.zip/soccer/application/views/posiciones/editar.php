<!-- Contact Start -->
<div class="container-fluid py-5 mb-5">
    <div class="container">
        <div class="text-center mx-auto pb-5 wow fadeIn" style="max-width: 600px;">
            <h5 class="text-primary">Posiciones</h5>
            <h1 class="mb-3">Editar Posición</h1>
        </div>
        <form class="row g-5 mb-5" action="<?php echo site_url('posiciones/actualizarPosicion');?>" method="post" id="frm_editar_posicion">
            <div class="col-md-2"></div>
            <div class="col-lg-8 wow fadeIn">
                <div class="p-5 rounded bg-primary">
                    <div class="mb-4">
                        <label for="nombre_pos" style="color: white;"><b>Nombre</b></label>
                        <input type="text" class="form-control border-0 py-3" name="nombre_pos" id="nombre_pos" placeholder="Ingrese el nombre de la posición" value="<?php echo isset($posicion->nombre_pos) ? $posicion->nombre_pos : ''; ?>" required>
                    </div>
                    <div class="mb-4">
                        <label for="descripcion_pos" style="color: white;"><b>Descripción</b></label>
                        <textarea class="form-control border-0 py-3" name="descripcion_pos" id="descripcion_pos" placeholder="Ingrese la descripción de la posición" required><?php echo isset($posicion->descripcion_pos) ? $posicion->descripcion_pos : ''; ?></textarea>
                    </div>
                    <input type="hidden" name="id_pos" value="<?php echo isset($posicion->id_pos) ? $posicion->id_pos : ''; ?>">
                    <div class="text-start">
                        <button class="btn bg-success text-white py-3 px-5" type="submit">Actualizar Posición</button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<!-- Contact End -->

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<!-- jQuery Validate -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.20.0/jquery.validate.min.js" integrity="sha512-WMEKGZ7L5LWgaPeJtw9MBM4i5w5OSBlSjTjCtSnvFJGSVD26gE5+Td12qN5pvWXhuWaWcVwF++F7aqu9cvqP0A==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.20.0/additional-methods.min.js" integrity="sha512-TiQST7x/0aMjgVTcep29gi+q5Lk5gVTUPE9XgN0g96rwtjEjLpod4mlBRKWHeBcvGBAEvJBmfDqh2hfMMmg+5A==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<script type="text/javascript">
  $(document).ready(function () {
    $.validator.addMethod("letrasSolo", function(value, element) {
      return /^[a-zA-Z\s]+$/.test(value);
    }, "Ingrese solo letras.");

    $("#frm_editar_posicion").validate({
      rules:{
        "nombre_pos":{
          required:true,
          letrasSolo:true
        },
        "descripcion_pos":{
          required:true
        }
      },
      messages:{
        "nombre_pos":{
          required:"Debe ingresar el nombre de la posición",
          letrasSolo:"Debe ingresar solo letras"
        },
        "descripcion_pos":{
          required:"Debe ingresar la descripción de la posición"
        }
      }
    });
  });
</script>

<style media="screen">
  label.error {
    color: white;
    font-weight: bold;
  }
</style>
