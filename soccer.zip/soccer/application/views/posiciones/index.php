<!-- Contact Start -->
<div class="container-fluid py-5 mb-5">
    <div class="container">
        <div class="text-center mx-auto pb-5 wow fadeIn" style="max-width: 600px;">
            <h5 class="text-primary">Posición</h5>
            <h1 class="mb-3">Visualización de Posiciones</h1>
        </div>
        <div class="row g-5 mb-5 text-center table-responsive">
            <?php if ($listadoPosiciones): ?>
                <table class="table table-responsive align-middle text-center table-striped" id="tbl_posiciones">
                    <thead>
                        <tr class="bg-primary" style="color: white">
                            <th class="text-center">#</th>
                            <th class="text-center">Nombre</th>
                            <th class="text-center">Descripción</th>
                            <th class="text-center">Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($listadoPosiciones as $posicion): ?>
                            <tr>
                                <td><?php echo $posicion->id_pos; ?></td>
                                <td><?php echo $posicion->nombre_pos; ?></td>
                                <td><?php echo $posicion->descripcion_pos; ?></td>
                                <td>
                                  <a href="#" onclick="confirmarEliminacionPosicion(<?php echo $posicion->id_pos; ?>);" class="btn btn-danger btn-sm"><i class="fa fa-eraser" aria-hidden="true"></i></a>
                                    <a href="<?php echo site_url('posiciones/editar/').$posicion->id_pos; ?>"><button type="button" name="button" class="btn btn-success btn-sm"><i class="fa fa-pencil" aria-hidden="true"></i></button></a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>No hay posiciones disponibles.</p>
            <?php endif; ?>
        </div>
    </div>
</div>
<!-- Contact End -->

<!-- jQuery -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.7.1/jquery.min.js" integrity="sha512-v2CJ7UaYy4JwqLDIrZUI/4hqeoQieOmAZNXBeQyjo21dadnwR+8ZaIJVT8EE2iyI61OV8e6M8PP2/4hpQINQ/g==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

<!-- jQuery Validate -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.20.0/jquery.validate.min.js" integrity="sha512-WMEKGZ7L5LWgaPeJtw9MBM4i5w5OSBlSjTjCtSnvFJGSVD26gE5+Td12qN5pvWXhuWaWcVwF++F7aqu9cvqP0A==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.20.0/additional-methods.min.js" integrity="sha512-TiQST7x/0aMjgVTcep29gi+q5Lk5gVTUPE9XgN0g96rwtjEjLpod4mlBRKWHeBcvGBAEvJBmfDqh2hfMMmg+5A==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
